package Javonet::Core::AbstractHandler;
use strict;
use warnings FATAL => 'all';
use Moose;

sub handle_command {

}

no Moose;
1;
