# -*- coding: utf-8 -*-
"""
The delegateCache package contains delegate caching implementation.
"""
