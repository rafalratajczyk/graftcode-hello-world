# -*- coding: utf-8 -*-
"""
The callback package contains callback function implementation.
"""
