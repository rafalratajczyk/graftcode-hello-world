# -*- coding: utf-8 -*-
"""
The namespaceCache package contains namespace caching implementation.
"""
