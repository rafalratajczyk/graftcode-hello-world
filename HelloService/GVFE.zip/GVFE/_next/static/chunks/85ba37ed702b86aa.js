(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,77369,t=>{"use strict";let e=null,s=async()=>(e||(e=t.A(38898)),e);t.s([],79599),t.i(79599),t.s(["loadJavonet",0,s],77369)},38898,t=>{t.v(e=>Promise.all(["static/chunks/3cc021eeb805662d.js"].map(e=>t.l(e))).then(()=>e(1751)))}]);

//# sourceMappingURL=e8f55f0e01093360.js.map